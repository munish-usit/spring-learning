package com.albertsons.idgraph.service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.albertsons.idgraph.primary.model.CustAccount;
import com.albertsons.idgraph.primary.model.IDGraphCustUnifiedDataModel;
import com.albertsons.idgraph.primary.model.IDGraphDataModel;
import com.albertsons.idgraph.primary.model.UCACustomerAccount;
import com.albertsons.idgraph.primary.repository.IDGraphCustUnifiedRepository;
import com.albertsons.idgraph.primary.repository.IDGraphRepository;
import com.albertsons.idgraph.secondary.model.CustomerProfileModel;
import com.albertsons.idgraph.secondary.repository.CustomerProfileRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CustomerService {

	@Autowired
	private IDGraphRepository idGraphRepositroy;

	@Autowired
	private IDGraphCustUnifiedRepository idGraphCustUnifiedRepository;
	
	@Autowired
	private CustomerProfileRepository customerProfileRepository;

	@Value("${idgraph.collections.batchsize}")
	private String batchSize;

	private Executor executor = Executors.newFixedThreadPool(16);

	public void compareCollections() {

		log.info("compare collections and save data , batch size {} ", batchSize);
		PageRequest page = PageRequest.of(0, Integer.valueOf(batchSize));

		Page<IDGraphDataModel> result = idGraphRepositroy.findAll(page);
		
		processCollections(result.getPageable().getPageNumber(), result.getContent());

		while (result.hasNext()) {
			result = idGraphRepositroy.findAll(result.nextPageable());
			processCollections(result.getPageable().getPageNumber(), result.getContent());
		}
	}

	private void processCollections(int pageNum, List<IDGraphDataModel> graphDataModelList) {
		CompletableFuture.runAsync(() -> {
			log.info("thread {} process collections for page number {} list size {} ", Thread.currentThread().getName(),pageNum, graphDataModelList.size());
			for (IDGraphDataModel collectionAData : graphDataModelList) {

				String unifiedId = collectionAData.getUnifiedId();
				log.info("thread {} processing for unifiedId {} ", Thread.currentThread().getName(),unifiedId);
				Optional<IDGraphCustUnifiedDataModel> collectionBOptional = idGraphCustUnifiedRepository
						.findByUnifiedId(collectionAData.getUnifiedId());

				IDGraphCustUnifiedDataModel dataSave = new IDGraphCustUnifiedDataModel();
				dataSave.setUnifiedId(collectionAData.getUnifiedId());
				dataSave.setCustAccounts(collectionAData.getCustAccounts());

				if (collectionBOptional.isPresent()) {
					log.info("thread {} processing unifiedId present in collectionB so deleting first {} ", Thread.currentThread().getName(),unifiedId);
					idGraphCustUnifiedRepository.delete(collectionBOptional.get());
				}
				log.info("thread {} processing unifiedId saving in collectionB {} ", Thread.currentThread().getName(),unifiedId);
				idGraphCustUnifiedRepository.save(dataSave);
				sendToKafka(unifiedId);
			}
		}, executor);

	}
	
	private void sendToKafka(String unifiedId) {
		log.info("thread {} send to kafka unifiedId {}", Thread.currentThread().getName(),unifiedId);
		Optional<IDGraphCustUnifiedDataModel> collectionBOptional = idGraphCustUnifiedRepository.findByUnifiedId(unifiedId);
		if(collectionBOptional.isEmpty()) {
			log.info("thread {} send to kafka unifiedId {} not found ", Thread.currentThread().getName(),unifiedId);
			return;
		}
		IDGraphCustUnifiedDataModel data = collectionBOptional.get();
		for(CustAccount custAccount : data.getCustAccounts()) {
			
			String reatailId = custAccount.getRetailUUId();
			
			UCACustomerAccount customerAccount = UCACustomerAccount.builder()
					.retailUUId(reatailId)
					.householdId(custAccount.getHouseholdId())
					.matchComponentsFlattened(custAccount.getMatchComponentsFlattened())
					.matchConfidence(custAccount.getMatchConfidence())
					.build();
			
			log.info("thread {} send to kafka unifiedId {} retail Id {} ", Thread.currentThread().getName(),unifiedId,reatailId);
			Optional<CustomerProfileModel> optionalReatail = customerProfileRepository.findByRetailUUId(reatailId);
			if(optionalReatail.isEmpty()) {
				log.info("thread {} send to kafka nothing to enrich unifiedId {} retail Id {} ", Thread.currentThread().getName(),unifiedId,reatailId);
			}else {
				CustomerProfileModel customerProfile = optionalReatail.get();
				customerAccount.setHouseholdId(customerProfile.getHouseholdId());
				if(customerProfile.getFreshPass() != null) {
					customerAccount.setFreshPassSubscriptionStatusCd(customerProfile.getFreshPass().getFreshPassSubscriptionStatusCd());
				}
				if(customerProfile.getIndicators() != null) {
					customerAccount.setScheduleAndSaveInd(customerProfile.getIndicators().getScheduleAndSaveIndicator());
					customerAccount.setSincerelyHealthInd(customerProfile.getIndicators().getSincerelyHealthIndicator());
				}
				if(customerProfile.getLastEvents() != null) {
					customerAccount.setLastStoreVisitDt(customerProfile.getLastEvents().getLastStoreVistDt());
					customerAccount.setLastWebVisitDt(customerProfile.getLastEvents().getLastWebVistDt());
				}
				log.info("thread {} send to kafka enrichment done unifiedId {} customerAccount {} ", Thread.currentThread().getName(),unifiedId,customerAccount);
			}
		}
	}
	
	

	/**
	 * private boolean compare(List<CustAccount> custAccounts, List<CustAccount>
	 * custAccounts2) { for(CustAccount custAccount1 : custAccounts) { CustAccount
	 * custAccount2 = isRetailIdPresent(custAccount1.getRetailUUId(),
	 * custAccounts2); if(custAccount2 != null) { boolean hMatch =
	 * custAccount1.getHouseholdId().equalsIgnoreCase(custAccount2.getHouseholdId());
	 * boolean confMatch =
	 * custAccount1.getMatchConfidence().equalsIgnoreCase(custAccount2.getMatchConfidence());
	 * boolean compMatch =
	 * custAccount1.getMatchComponentsFlattened().equalsIgnoreCase(custAccount2.getMatchComponentsFlattened());
	 * 
	 * if(hMatch && confMatch && compMatch == false) return false; } else {
	 * log.info("No match found for collectionA retailId {}
	 * ",custAccount1.getRetailUUId()); return false; } } return true; }
	 * 
	 * private CustAccount isRetailIdPresent(String retailUid, List<CustAccount>
	 * custAccounts2) { for(CustAccount custAccount : custAccounts2) {
	 * if(retailUid.equalsIgnoreCase(custAccount.getRetailUUId())) return
	 * custAccount; } return null; }
	 **/

}
