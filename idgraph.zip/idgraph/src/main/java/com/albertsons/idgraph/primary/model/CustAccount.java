package com.albertsons.idgraph.primary.model;

import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown=true)
@ToString
@NoArgsConstructor
@Setter
@Getter
public class CustAccount {

	@Field("retail_uuid")
    private String retailUUId;

	@Field("household_id")
    private String householdId;

	@Field("matchcomponents_flattened")
    private String matchComponentsFlattened;
	
	@Field("matchconfidence")
    private String matchConfidence;
}
