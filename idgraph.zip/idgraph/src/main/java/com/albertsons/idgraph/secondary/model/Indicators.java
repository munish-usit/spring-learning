package com.albertsons.idgraph.secondary.model;

import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown=true)
@ToString
@NoArgsConstructor
@Setter
@Getter
public class Indicators {

    @Field("new_customer_indicator")
    private String newCustomerIndicator;

    @Field("dug_txn_indicator")
    private Boolean dugTxnIndicator;

    @Field("delivery_txn_indicator")
    private Boolean deliveryTxnIndicator;

    @Field("own_brand_purchase_indicator")
    private Boolean ownBrandPurchaseIndicator;

    @Field("alcohol_purchase_indicator")
    private Boolean alcoholPurchaseIndicator;
    
    @Field("instore_transaction_ind")
    private Boolean instoreTransactionIndicator;

    @Field("sms_launch_target_ind")
    private Boolean smsLaunchTargetIndicator;
    
    @Field("sincerely_health_ind")
    private Boolean sincerelyHealthIndicator;
    
    @Field("schedule_and_save_ind")
    private Boolean scheduleAndSaveIndicator;
    

}
