package com.albertsons.idgraph.secondary.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.albertsons.idgraph.secondary.model.CustomerProfileModel;

public interface CustomerProfileRepository extends MongoRepository<CustomerProfileModel, String>{

	public Optional<CustomerProfileModel> findByRetailUUId(String retailId);
}
