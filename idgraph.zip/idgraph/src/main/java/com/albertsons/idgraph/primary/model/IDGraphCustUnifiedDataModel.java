package com.albertsons.idgraph.primary.model;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Document(collection = "idgraph_cust_unified_data")
@JsonIgnoreProperties(ignoreUnknown=true)
@ToString
@NoArgsConstructor
@Setter
@Getter
public class IDGraphCustUnifiedDataModel {

    @Id
	private ObjectId id;
    
    @Field("unified_id")
    private String unifiedId;

    @Field("custAccounts")
    private List<CustAccount> custAccounts;
}