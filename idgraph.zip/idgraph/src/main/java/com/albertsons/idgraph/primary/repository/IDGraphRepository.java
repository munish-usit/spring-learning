package com.albertsons.idgraph.primary.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.albertsons.idgraph.primary.model.IDGraphDataModel;

@Repository
public interface IDGraphRepository extends MongoRepository<IDGraphDataModel,String> {

}
