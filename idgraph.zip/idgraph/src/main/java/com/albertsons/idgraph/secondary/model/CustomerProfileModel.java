package com.albertsons.idgraph.secondary.model;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Document(collection = "c360_customer_profile")
@JsonIgnoreProperties(ignoreUnknown=true)
@ToString
@NoArgsConstructor
@Setter
@Getter
public class CustomerProfileModel {

	@Id
	private ObjectId id;

	@Field("uuid")
	private String retailUUId;
	
	@Field("club_card_nbr")
	private String clubCardNbr;

	@Field("household_id")
	private String householdId;
	
	@Field("freshPass")
	private FreshPass freshPass;

	@Field("indicators")
	private Indicators indicators;
	
	//@Field("eng_mode")
	//private EngMode engMode;
	
	//@Field("meal_preferences")
	//private MealPreference mealPreference;
	
	@Field("last_events")
	private LastEvents lastEvents;
	
}
