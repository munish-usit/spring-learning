package com.albertsons.idgraph.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.albertsons.idgraph.service.CustomerService;


@RestController
public class JobSuccessController {

	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/compare-collections")
	public ResponseEntity<String> compareCollections() {
		customerService.compareCollections();
		return ResponseEntity.ok("success");
	}
	
}
