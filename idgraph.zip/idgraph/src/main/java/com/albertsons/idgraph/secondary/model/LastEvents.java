package com.albertsons.idgraph.secondary.model;

import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown=true)
@ToString
@NoArgsConstructor
@Setter
@Getter
public class LastEvents {

	@Field("last_store_visit_dt")
	private String lastStoreVistDt;
	
	@Field("last_web_visit_dt")
	private String lastWebVistDt;
}
