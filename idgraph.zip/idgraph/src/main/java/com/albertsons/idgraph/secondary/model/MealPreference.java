package com.albertsons.idgraph.secondary.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown=true)
@ToString
@NoArgsConstructor
@Setter
@Getter
public class MealPreference {

}
