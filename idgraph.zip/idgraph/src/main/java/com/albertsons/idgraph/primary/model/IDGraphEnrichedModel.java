package com.albertsons.idgraph.primary.model;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@Setter
@Getter
public class IDGraphEnrichedModel {
	@Id
	private ObjectId id;

	@JsonProperty("unified_id")
	private String unifiedId;

	@JsonProperty("custAccounts")
	private List<UCACustomerAccount> custAccounts;
}
