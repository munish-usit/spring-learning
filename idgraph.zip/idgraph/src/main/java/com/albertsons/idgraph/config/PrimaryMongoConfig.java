package com.albertsons.idgraph.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@EnableMongoRepositories(basePackages = {
		"com.albertsons.idgraph.primary.repository" }, mongoTemplateRef = "primaryMongoTemplate")
public class PrimaryMongoConfig {
	
	@Bean(name = "primaryProperties")
	@ConfigurationProperties(prefix = "mongodb.primary")
	@Primary
	public MongoProperties primaryProperties() {
		return new MongoProperties();
	}

	@Primary
	@Bean(name = "primaryMongoDBFactory")
	public MongoDatabaseFactory primaryMongoDatabaseFactory(@Qualifier("primaryProperties") MongoProperties mongoProperties) {
		return new SimpleMongoClientDatabaseFactory(mongoProperties.getUri());
	}

	@Primary
	@Bean(name = "primaryMongoTemplate")
	public MongoTemplate primaryMongoTemplate(@Qualifier("primaryMongoDBFactory") MongoDatabaseFactory mongoDatabaseFactory) {
		return new MongoTemplate(primaryMongoDatabaseFactory(primaryProperties()));
	}
}
