package com.albertsons.idgraph.primary.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.albertsons.idgraph.primary.model.IDGraphCustUnifiedDataModel;

@Repository
public interface IDGraphCustUnifiedRepository extends MongoRepository<IDGraphCustUnifiedDataModel,String> {
	
	public Optional<IDGraphCustUnifiedDataModel> findByUnifiedId(String unifiedId);
}
