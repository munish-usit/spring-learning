package com.albertsons.idgraph.primary.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class UCACustomerAccount {

	@JsonProperty("retail_uuid")
	private String retailUUId;

	@JsonProperty("household_id")
	private String householdId;

	@JsonProperty("freshpass_subscription_status_cd")
	private String freshPassSubscriptionStatusCd;

	@JsonProperty("schedule_and_save_ind")
	private Boolean scheduleAndSaveInd;

	@JsonProperty("sincerely_health_ind")
	private Boolean sincerelyHealthInd;

	@JsonProperty("last_store_visit_dt")
	private String lastStoreVisitDt;

	@JsonProperty("last_web_visit_dt")
	private String lastWebVisitDt;

	@JsonProperty("matchcomponents_flattened")
	private String matchComponentsFlattened;

	@JsonProperty("matchconfidence")
	private String matchConfidence;

}
