package com.albertsons.idgraph;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdgraphApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdgraphApplication.class, args);
	}

}
